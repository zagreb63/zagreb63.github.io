﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        //const logger = Logger.getLogger('watchface_SashaCX75');
        const logger = DeviceRuntimeCore.HmLogger.getLogger('watchface_SashaCX75')
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_battery_icon_img = ''
        let normal_battery_current_text_font = ''
        let normal_battery_image_progress_img_level = ''
        let normal_step_current_text_img = ''
        let normal_step_icon_img = ''
        let normal_date_img_date_month_img = ''
        let normal_date_img_date_week_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_temperature_current_text_img = ''
        let normal_date_img_date_day = ''
        let normal_system_dnd_img = ''
        let normal_system_lock_img = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let normal_digital_clock_img_time = ''
        let idle_background_bg_img = ''
        let idle_battery_icon_img = ''
        let idle_battery_current_text_font = ''
        let idle_battery_image_progress_img_level = ''
        let idle_system_dnd_img = ''
        let idle_system_lock_img = ''
        let idle_system_disconnect_img = ''
        let idle_system_clock_img = ''
        let idle_digital_clock_img_time = ''
        let normal_temperature_jumpable_img_click = ''
        let normal_countdown_jumpable_img_click = ''
        let normal_alarm_jumpable_img_click = ''
        let normal_step_jumpable_img_click = ''
        let Button_1 = ''
        let Button_Switch_BG = ''

        let backgroundIndex = 0;
        let backgroundList = ['0001.png', '0048.png', '0049.png', '0050.png', '0051.png', '0052.png', '0053.png', '0054.png', '0055.png', '0056.png', '0057.png'];
        let backgroundToastList = ['Фон %s', 'Фон %s', 'Фон %s', 'Фон %s', 'Фон %s', 'Фон %s', 'Фон %s', 'Фон %s', 'Фон %s', 'Фон %s', 'Фон %s'];
        const watchfaceId = hmApp.packageInfo().watchfaceId;


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            //#region SwitchBackground
            console.log('SwitchBackground');
            function switchBackground() {
              backgroundIndex++;
              if (backgroundIndex >= backgroundList.length) backgroundIndex = 0;
              hmFS.SysProSetInt(`backgroundIndex_${watchfaceId}`, backgroundIndex);
              let toastText = backgroundToastList[backgroundIndex].replace('%s', `${backgroundIndex + 1}`);
              if (toastText.length > 0) hmUI.showToast({text: toastText});
              normal_background_bg_img.setProperty(hmUI.prop.SRC, backgroundList[backgroundIndex]);
            };
            //#endregion

            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 390,
              h: 450,
              src: '0001.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 250,
              y: 53,
              src: 'Bat_Contur.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 304,
              y: 44,
              w: 76,
              h: 40,
              text_size: 35,
              char_space: -3,
              color: 0xFFC0C0C0,
              line_space: 0,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              unit_type: 1,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 258,
              y: 58,
              image_array: ["b_0.png","b_1.png","b_2.png","b_3.png","b_4.png","b_5.png","b_6.png","b_7.png","b_8.png","b_9.png"],
              image_length: 10,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 45,
              y: 366,
              font_array: ["0013.png","0014.png","0015.png","0016.png","0017.png","0018.png","0019.png","0020.png","0021.png","0022.png"],
              padding: false,
              h_space: 3,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 15,
              y: 371,
              src: 'Steps.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 105,
              month_startY: 22,
              month_sc_array: ["0034.png","0035.png","0036.png","0037.png","0038.png","0039.png","0040.png","0041.png","0042.png","0043.png","0044.png","0045.png"],
              month_tc_array: ["0034.png","0035.png","0036.png","0037.png","0038.png","0039.png","0040.png","0041.png","0042.png","0043.png","0044.png","0045.png"],
              month_en_array: ["0034.png","0035.png","0036.png","0037.png","0038.png","0039.png","0040.png","0041.png","0042.png","0043.png","0044.png","0045.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 105,
              y: 57,
              week_en: ["d_1.png","d_2.png","d_3.png","d_4.png","d_5.png","d_6.png","d_7.png"],
              week_tc: ["d_1.png","d_2.png","d_3.png","d_4.png","d_5.png","d_6.png","d_7.png"],
              week_sc: ["d_1.png","d_2.png","d_3.png","d_4.png","d_5.png","d_6.png","d_7.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 212,
              y: 375,
              image_array: ["W_0.png","W_1.png","W_2.png","W_3.png","W_4.png","W_5.png","W_6.png","W_7.png","W_8.png","W_9.png","W_10.png","W_11.png","W_12.png","W_13.png","W_14.png","W_15.png","W_16.png","W_17.png","W_18.png","W_19.png","W_20.png","W_21.png","W_22.png","W_23.png","W_24.png","W_25.png","W_26.png","W_27.png","W_28.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 262,
              y: 366,
              font_array: ["0013.png","0014.png","0015.png","0016.png","0017.png","0018.png","0019.png","0020.png","0021.png","0022.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'Gradus.png',
              unit_tc: 'Gradus.png',
              unit_en: 'Gradus.png',
              negative_image: 'Slash.png',
              invalid_image: 'Vopros.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 30,
              day_startY: 21,
              day_sc_array: ["0013.png","0014.png","0015.png","0016.png","0017.png","0018.png","0019.png","0020.png","0021.png","0022.png"],
              day_tc_array: ["0013.png","0014.png","0015.png","0016.png","0017.png","0018.png","0019.png","0020.png","0021.png","0022.png"],
              day_en_array: ["0013.png","0014.png","0015.png","0016.png","0017.png","0018.png","0019.png","0020.png","0021.png","0022.png"],
              day_zero: 1,
              day_space: 5,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_dnd_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 279,
              y: 19,
              src: '0023.png',
              type: hmUI.system_status.DISTURB,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_lock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 324,
              y: 19,
              src: '0026.png',
              type: hmUI.system_status.LOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 299,
              y: 19,
              src: '0024.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 255,
              y: 20,
              src: '0025.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 29,
              hour_startY: 105,
              hour_array: ["n0.png","n1.png","n2.png","n3.png","n4.png","n5.png","n6.png","n7.png","n8.png","n9.png"],
              hour_zero: 1,
              hour_space: 6,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,

              minute_startX: 214,
              minute_startY: 104,
              minute_array: ["n0.png","n1.png","n2.png","n3.png","n4.png","n5.png","n6.png","n7.png","n8.png","n9.png"],
              minute_zero: 1,
              minute_space: 6,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.CENTER_H,

              second_startX: -41,
              second_startY: 165,
              second_array: ["anim_s0.png","anim_s1.png","anim_s2.png","anim_s3.png","anim_s4.png","anim_s5.png","anim_s6.png","anim_s7.png","anim_s8.png","anim_s9.png"],
              second_zero: 1,
              second_space: 200,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.RIGHT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');
            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 390,
              h: 450,
              src: '0001.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 250,
              y: 53,
              src: 'Bat_Contur.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 304,
              y: 44,
              w: 76,
              h: 40,
              text_size: 35,
              char_space: -3,
              color: 0xFFC0C0C0,
              line_space: 0,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              unit_type: 1,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 258,
              y: 58,
              image_array: ["b_0.png","b_1.png","b_2.png","b_3.png","b_4.png","b_5.png","b_6.png","b_7.png","b_8.png","b_9.png"],
              image_length: 10,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_dnd_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 279,
              y: 19,
              src: '0023.png',
              type: hmUI.system_status.DISTURB,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_lock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 324,
              y: 19,
              src: '0026.png',
              type: hmUI.system_status.LOCK,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 299,
              y: 19,
              src: '0024.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 255,
              y: 20,
              src: '0025.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 29,
              hour_startY: 105,
              hour_array: ["n0.png","n1.png","n2.png","n3.png","n4.png","n5.png","n6.png","n7.png","n8.png","n9.png"],
              hour_zero: 1,
              hour_space: 6,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,

              minute_startX: 214,
              minute_startY: 105,
              minute_array: ["n0.png","n1.png","n2.png","n3.png","n4.png","n5.png","n6.png","n7.png","n8.png","n9.png"],
              minute_zero: 1,
              minute_space: 6,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.CENTER_H,

              second_startX: -41,
              second_startY: 165,
              second_array: ["anim_s0.png","anim_s1.png","anim_s2.png","anim_s3.png","anim_s4.png","anim_s5.png","anim_s6.png","anim_s7.png","anim_s8.png","anim_s9.png"],
              second_zero: 1,
              second_space: 200,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.RIGHT,

              show_level: hmUI.show_level.ONLY_AOD,
            });
            
            // disconnectAlert = hmUI.createWidget(hmUI.widget.DisconnectAlert, {
              // disconneсnt_vibrate_type: 9,
              // disconneсnt_toast_text: А где телефон ?,
            // });

            // vibration when connecting or disconnecting

            function checkConnection() {
              console.log('checkConnection()');
              hmBle.removeListener;
              hmBle.addListener(function (status) {
                if(!status) {
                  hmUI.showToast({text: "А где телефон ?"});
                  vibro(9);
                }
              });
            }

            // end vibration when connecting or disconnecting
            //#region vibrate function

            const vibrate = hmSensor.createSensor(hmSensor.id.VIBRATE);
            let timer_StopVibrate = null;


            function vibro(scene = 25) {
              let stopDelay = 50;
              stopVibro();
              vibrate.stop();
              vibrate.scene = scene;
              if(scene < 23 || scene > 25) stopDelay = 1300;
              vibrate.start();
              if (scene != 1) timer_StopVibrate = timer.createTimer(stopDelay, 3000, stopVibro, {});
            }

            function stopVibro(){
              vibrate.stop();
              if(timer_StopVibrate) timer.stopTimer(timer_StopVibrate);
            }

            //#endregion
            console.log('Watch_Face.Shortcuts');

            normal_temperature_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 208,
              y: 335,
              w: 179,
              h: 115,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_countdown_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 209,
              y: 110,
              w: 158,
              h: 207,
              type: hmUI.data_type.COUNT_DOWN,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_alarm_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 22,
              y: 110,
              w: 159,
              h: 206,
              src: '0047.png',
              type: hmUI.data_type.ALARM_CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 3,
              y: 335,
              w: 200,
              h: 115,
              src: '0047.png',
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            console.log('Watch_Face.Buttons');
            Button_1 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 23,
              y: 0,
              w: 218,
              h: 91,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0047.png',
              normal_src: '0047.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'ScheduleCalScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            console.log('Watch_Face.SwitchBackground');
            // Button_Switch_BG = hmUI.createWidget(hmUI.widget.SwitchBackground, {
              // x: 248,
              // y: 2,
              // w: 130,
              // h: 89,
              // text: '',
              // color: 0xFFFF8C00,
              // text_size: 25,
              // press_src: '0047.png',
              // normal_src: '0047.png',
              // bg_list: 0001|0048|0049|0050|0051|0052|0053|0054|0055|0056|0057,
              // toast_list: Фон %s|Фон %s|Фон %s|Фон %s|Фон %s|Фон %s|Фон %s|Фон %s|Фон %s|Фон %s|Фон %s,
              // use_crown: False,
              // use_in_AOD: False,
              // vibro: False,
            // });

            Button_Switch_BG = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 248,
              y: 2,
              w: 130,
              h: 89,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0047.png',
              normal_src: '0047.png',
              click_func: (button_widget) => {
                switchBackground();
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            let screenType = hmSetting.getScreenType();
            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                console.log('resume_call()');
                checkConnection();
                stopVibro();

                //SwitchBackground
                if (hmFS.SysProGetInt(`backgroundIndex_${watchfaceId}`) === undefined) {
                  backgroundIndex = 0;
                  hmFS.SysProSetInt(`backgroundIndex_${watchfaceId}`, backgroundIndex);
                } else {
                  backgroundIndex = hmFS.SysProGetInt(`backgroundIndex_${watchfaceId}`);
                };
                if (screenType == hmSetting.screen_type.WATCHFACE && normal_background_bg_img) normal_background_bg_img.setProperty(hmUI.prop.SRC, backgroundList[backgroundIndex]);
              }),
              pause_call: (function () {
                console.log('pause_call()');
                stopVibro();

              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}